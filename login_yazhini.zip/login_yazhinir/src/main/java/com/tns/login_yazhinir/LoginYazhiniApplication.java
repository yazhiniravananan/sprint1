package com.tns.login_yazhinir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginYazhiniApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginYazhiniApplication.class, args);
	}

}
