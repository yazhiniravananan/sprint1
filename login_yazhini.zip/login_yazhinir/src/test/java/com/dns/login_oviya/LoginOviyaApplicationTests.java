package com.dns.login_oviya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginOviyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
